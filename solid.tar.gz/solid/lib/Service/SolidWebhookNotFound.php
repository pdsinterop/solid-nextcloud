<?php

namespace OCA\Solid\Service;

class SolidWebhookNotFound extends \Exception {
}
