<?php

	declare(strict_types=1);

	$app = \OC::$server->query(\OCA\Solid\AppInfo\SolidApp::class);
