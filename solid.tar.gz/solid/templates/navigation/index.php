<?php if (isset($_['solidNavigation'])) { ?>
<ul>
    <li><a href="<?php p($_['solidNavigation']['launcher']); ?>"><img src="/core/img/actions/star-dark.svg"><span>Solid Apps</span></a></li>
    <li><a data-simply-command="profile" href="<?php p($_['solidNavigation']['profile']);?>"><img src="/core/img/actions/user.svg"><span>Profile</span></a></li>
</ul>
<?php } ?>