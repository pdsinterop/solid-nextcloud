<ul class="with-icon">
    <li><a class="icon-star-dark" href="<?php p($_['solidNavigation']['launcher']); ?>">Solid Apps</a></li>
    <li><a data-simply-command="profile" class="icon-user" href="<?php p($_['solidNavigation']['profile']);?>">Profile</a></li>
</ul>
