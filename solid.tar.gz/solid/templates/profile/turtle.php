<?php
	header("Content-type: text/turtle");
    p($_['turtleProfile']);
    // phpcs:disable PSR2.Files.ClosingTag.NotAllowed
    // phpcs:disable PSR2.Files.EndFileNewline.NoneFound
?>