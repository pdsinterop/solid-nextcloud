<?php
	header("Content-type: text/turtle");
    p($_['turtleProfile']);
?>